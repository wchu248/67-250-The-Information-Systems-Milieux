function showDescription(descript){
    $("#description").html("Description: " + descript);
}

function hideDescription(){
    $("#description").html("")
}

function validate(){
    var zipCode = $("#zipcode").val();
    var numZipDigits = zipCode.length;
    if(numZipDigits == 0){
    } else if(isNaN(zipCode) || numZipDigits != 5){
        alert("Zip code is not valid or not in valid format.")
        return false;
    } 
    alert("Thank you! We will be sure to help you with your inquiry.")
}

function warning(){
    alert("This page is only for store managers and employees. If you are a cutomer, we respectfully ask you to not look at the data.")
}